function Q = computeNode(name,inputs,weight,offset)
    
    %initialize the aggregated node with the first input
    aggregated = inputs{1}*weight(1);
    
    %check if we need to aggregate
    if length(inputs)>1
       if contains(name,'*') %aggragate by multiplication
           for i = 2:length(inputs)
                aggregated = aggregated .*inputs{i}*weight(i);
           end
       else                 %aggragate by addition
           for i = 2:length(inputs)
                aggregated = aggregated + inputs{i}*weight(i);
           end
       end
    end
        
    if contains(name,'iden','IgnoreCase',true)
        Q = aggregated               + offset;
    elseif contains(name,'atsn','IgnoreCase',true) 
        Q = atan(20*sin(aggregated)) + offset;
    elseif contains(name,'atan','IgnoreCase',true) 
        Q = atan(aggregated)          + offset;
    elseif contains(name,'sin','IgnoreCase',true)                 
        Q = sin(aggregated)          + offset;
    elseif contains(name,'fourth','IgnoreCase',true)
        Q = aggregated.^4            + offset;
    elseif contains(name,'squared','IgnoreCase',true)
        Q = aggregated.^2            + offset;
    end
end