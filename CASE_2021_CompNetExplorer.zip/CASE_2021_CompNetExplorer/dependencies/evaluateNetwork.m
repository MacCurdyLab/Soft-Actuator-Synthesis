function Q = evaluateNetwork(Net,T,R,Z,pos,plotme)

%build the directed graph from the matrix representation
G = digraph(Net.Network,Net.Nodes);

if plotme ==1
    %plot the subgraph
    subplot('Position',pos)
    set(gcf,'units','inches')
    h = plot(G,'NodeLabel',{},'EdgeLabel',round(G.Edges.Weight,1),'MarkerSize',5,'NodeColor','r','EdgeColor','k','ArrowSize',10);
    text(h.XData+0.02,h.YData,strcat(table2cell(G.Nodes),', bias= ',cellstr(num2str(round(Net.Bias,1)'))),'FontSize',8);
end

%Set the nodevals
GnodesVals = cell(length(Net.Nodes),1);
GnodesVals{1} = T; GnodesVals{2} = R; GnodesVals{3} = Z;

for i = 4:length(Net.Nodes)
GnodesVals{i} = Net.Bias(i);
end
Q = computeGraph(G,Net.Nodes,GnodesVals);

end