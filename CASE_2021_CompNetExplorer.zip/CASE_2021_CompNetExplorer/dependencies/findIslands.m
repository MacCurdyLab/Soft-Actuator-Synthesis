function islands = findIslands(G)
    islands = [];
    for i = 1:height(G.Nodes)
       if isempty(outedges(G,i)) && isempty(inedges(G,i))
           islands = [islands i];
       end
    end
end