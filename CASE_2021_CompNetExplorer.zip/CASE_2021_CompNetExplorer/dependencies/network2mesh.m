function [finalmesh] = network2mesh(Net,MeshParams)

N = MeshParams.GridEval; %number of grid points in each direction
isovalue = MeshParams.IsoVal; %isovalue
e = MeshParams.ScalarExtents;
%Generate uniformly spaced grid points in X,Y,Z
n1 = linspace(0,e*pi,N); 
n2 = linspace(-e*pi/2,e*pi/2,N); 
[x,y,z] = meshgrid(n2,n2,n1);

%convert these cartesian points their polar coordinate equivalents
[T,R,Z] = cart2pol(x,y,z);

T = T+Net.Bias(1);
R = R+Net.Bias(2);
Z = Z+Net.Bias(3);

%Evaluate network at specified grid points
Q = evaluateNetwork(Net,T,R,Z,0,0);

%pad with large values
Q(:,:,[1 end]) = 10; Q(:,:,end) = 10;

%Generate initial isosurface through scalar field
initialmesh = isosurface(x,y,z,Q,isovalue);

%extract points and faces for remeshing
pts = initialmesh.vertices;
faces = initialmesh.faces;

if ~isempty(faces) && nnz(isnan(pts))<1

    %% Refine Triangulation for a Suitable FE Mesh
    if MeshParams.ResampleIter>0
        for i = 1: MeshParams.ResampleIter
            %Resample the mesh
            [pts, faces] = meshresample(pts,faces,0.8);
            %Smooth the mesh
            pts=sms(pts,faces,10,0.5);      
        end
    end
    pts = pts.*10;
    %triangulate the resampled mesh
    finalmesh = triangulation(faces,pts);
else
    finalmesh = [];
end

end