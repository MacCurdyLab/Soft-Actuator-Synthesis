function startpts = findStarts(G)
    startpts = [];
    for i = 1:height(G.Nodes)
       if ~isempty(outedges(G,i)) && isempty(inedges(G,i))
           startpts = [startpts i];
       end
    end
end