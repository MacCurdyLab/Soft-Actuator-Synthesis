function [Q] = computeGraph(G,nodes,nodevals)

while numedges(G)>0
    
    %remove islands from graph
    islands = findIslands(G);
    G = rmnode(G,islands);
    nodes(islands) = [];
    nodevals(islands) = [];

    %find startpts
    startpts = findStarts(G);
    
    non_startpts = 1:height(G.Nodes); non_startpts(startpts) = [];
    
    i = 0;
    while i<length(non_startpts)
        i=i+1;
        [ein, nid] = inedges(G,non_startpts(i));
        weight = G.Edges.Weight(ein);
        offset = nodevals{non_startpts(i)};
       
        if ismember(nid,startpts)

            %compute the new value of this node
            operation = string(nodes(non_startpts(i)));
            feedins = nodevals(nid);
            Q = computeNode(operation,feedins,weight,offset);

            %Assign this new value to the node
            nodevals{non_startpts(i)} = Q;

            %remove the edges that were inputs
            G = rmedge(G,nid,ones(length(nid),1)*non_startpts(i));
            i = length(non_startpts);              
        end      
    end
    
end
    
end